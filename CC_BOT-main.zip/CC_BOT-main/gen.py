import random
from datetime import datetime
from telebot import types


def send_message_with_inline_keyboard(bot, chat_id, response, message_id=None):
    inline_keyboard = [
        [types.InlineKeyboardButton(text="Generate Again", callback_data="/gen")]
    ]
    reply_markup = types.InlineKeyboardMarkup(inline_keyboard)

    bot.send_message(chat_id, response, parse_mode="HTML", reply_markup=reply_markup, reply_to_message_id=message_id)


def edit_message(bot, chat_id, message_id, text):
    inline_keyboard = [
        [types.InlineKeyboardButton(text="Generate Again", callback_data="/gen")]
    ]
    reply_markup = types.InlineKeyboardMarkup(inline_keyboard)

    bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, parse_mode="HTML", reply_markup=reply_markup)


def save_last_used_bin(user_id, bin):
    filename = f"bincache/last_used_bin_{user_id}.txt"
    with open(filename, "a") as file:
        file.write(f"{user_id} - {bin}\n")


def get_last_used_bin(user_id):
    filename = f"bincache/last_used_bin_{user_id}.txt"
    try:
        with open(filename, "r") as file:
            lines = file.readlines()
            if lines:
                last_record = lines[-1]
                _, bin = last_record.split(" - ")
                return bin.strip()
    except FileNotFoundError:
        return None


def generate_cc_number(bin, input):
    cc_number = bin
    remaining_digits = 16 - len(bin) - 1

    for _ in range(remaining_digits):
        cc_number += str(random.randint(0, 9))

    cc_number += calculate_luhn_check_digit(cc_number)
    return cc_number


def calculate_luhn_check_digit(number):
    sum = 0
    num_digits = len(number)
    parity = num_digits % 2

    for i in range(num_digits - 1, -1, -1):
        digit = int(number[i])

        if i % 2 != parity:
            digit *= 2
            if digit > 9:
                digit -= 9

        sum += digit

    check_digit = (10 - (sum % 10)) % 10
    return str(check_digit)


def generate_random_cvv():
    return str(random.randint(100, 999))


def generate_cc(input, quantity=10):
    cards_response = []

    for _ in range(quantity):
        cc_number = generate_cc_number(input, input)
        expiration_month = str(random.randint(1, 12)).zfill(2)
        expiration_year = str(random.randint(23, 33))
        cvv = generate_random_cvv()

        cards_response.append({
            'cc': cc_number,
            'mm': expiration_month,
            'yy': expiration_year,
            'cvv': cvv
        })

    response = f"<b>🧾Here are your cards Lolicon\n\n• Bin ⇾ {input}\n• Amount ⇾ {quantity}\n═════════════════</b>\n"
    for card in cards_response:
        response += f"<code>{card['cc']}|{card['mm']}|{card['yy']}|{card['cvv']}\n</code>"

    return response


def handle_gen_command(message, bot):
    try:
        input = message.text.split(" ")[1]
    except IndexError:
        bot.send_message(message.chat.id, "Please specify a card prefix. Usage: /gen <prefix>")
        return

    user_id = message.from_user.id
    save_last_used_bin(user_id, input)
    response = generate_cc(input, 10)
    send_message_with_inline_keyboard(bot, message.chat.id, response, message.message_id)


def handle_callback_query(callback_query, bot):
    data = callback_query.data
    message = callback_query.message
    chat_id = message.chat.id
    message_id = message.message_id
    user_id = callback_query.from_user.id

    if data == '/gen':
        input = get_last_used_bin(user_id)
        if not input:
            bot.answer_callback_query(callback_query.id, "No previous BIN found. Please use /gen <prefix> first.")
            return

        response = generate_cc(input, 10)
        edit_message(bot, chat_id, message_id, response)